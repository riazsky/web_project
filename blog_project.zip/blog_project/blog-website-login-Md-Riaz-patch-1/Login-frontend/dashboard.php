<?php
session_start();
require_once'includes/header.php';
require_once'includes/db.php';
$login_user = $_SESSION['user_email'];
//SELECT FIRST NAME FROM DATABASE START
$select_login_user = "SELECT first_name FROM users WHERE email_address ='$login_user'";
$select_login_user_from_db = mysqli_query($db_connect,$select_login_user);
$select_login_assoc = mysqli_fetch_assoc($select_login_user_from_db);

//SELECT FIRST NAME FROM DATABASE END

?>

  <!-- ########## START: LEFT PANEL ########## -->
  <div class="sl-logo"><a href=""><img width="100" src="images/kate-logo-white.png" alr="Nor Found"></div>
    <div class="sl-sideleft">
      <div class="input-group input-group-search">
        <input type="search" name="search" class="form-control" placeholder="Search">
        <span class="input-group-btn">
          <button class="btn"><i class="fa fa-search"></i></button>
        </span><!-- input-group-btn -->
      </div><!-- input-group -->

      <label class="sidebar-label">Kate</label>
      <div class="sl-sideleft-menu">
        <a href="dashboard.php" class="sl-menu-link">
          <div class="sl-menu-item">
            <i class="menu-item-icon icon ion-ios-home-outline tx-22"></i>
            <span class="menu-item-label">Dashboard</span>
          </div><!-- menu-item -->
        </a><!-- sl-menu-link -->
        </ul>
      </div><!-- sl-sideleft-menu -->

      <br>
    </div><!-- sl-sideleft -->
    <!-- ########## END: LEFT PANEL ########## -->

    <!-- ########## START: HEAD PANEL ########## -->
    <div class="sl-header">
      <div class="sl-header-left">
        <div class="navicon-left hidden-md-down"><a id="btnLeftMenu" href=""><i class="icon ion-navicon-round"></i></a></div>
        <div class="navicon-left hidden-lg-up"><a id="btnLeftMenuMobile" href=""><i class="icon ion-navicon-round"></i></a></div>
      </div><!-- sl-header-left -->
      <div class="sl-header-right">
        <nav class="nav">
          <div class="dropdown">
            <a href="" class="nav-link nav-link-profile" data-toggle="dropdown">
              <span class="logged-name"><?= $select_login_assoc['first_name']?></span></span>
              
            </a>
            <div class="dropdown-menu dropdown-menu-header wd-200" style="margin-right: 25%;">
              <ul class="list-unstyled user-profile-nav">
                   <li><a href="logout.php"><i class="icon ion-power"></i> Sign Out</a></li>
              </ul>
            </div><!-- dropdown-menu -->
          </div><!-- dropdown -->
        </nav>
      </div><!-- sl-header-right -->
    </div><!-- sl-header -->
    <!-- ########## END: HEAD PANEL ########## -->

   

    <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel">
      <nav class="breadcrumb sl-breadcrumb">
        <a class="breadcrumb-item" href="dashboard.php">Dashboard</a>
      </nav>

      <div class="sl-pagebody">
        <div class="sl-page-title">
          <h1>Welcome to Database</h1>
          <h2>Name: <?= $select_login_assoc['first_name']?></h2>
          <h2>Email: <?= $login_user?></h2>
        </div><!-- sl-page-title -->

      </div><!-- sl-pagebody -->
    </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->


<?php

require_once'includes/footer.php';

?>