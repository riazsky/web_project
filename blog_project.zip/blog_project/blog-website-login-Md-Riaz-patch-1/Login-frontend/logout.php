<?php
session_start();

unset($_SESSION['after_login']);
unset($_SESSION['user_email']);
header('location: fblogin.php');

?>