<?php
session_start();
require_once'includes/db.php';

$email_address = $_POST['email_address'];
$password = $_POST['password'];

//IDENTIFY EMAIIL AND PASSWORD START

$select_query = "SELECT COUNT(*) AS total FROM users WHERE email_address = '$email_address' AND password='$password'";
$select_from_db = mysqli_query($db_connect,$select_query);
$select_assoc = mysqli_fetch_assoc($select_from_db);

if($select_assoc['total'] == 1){

    $_SESSION['after_login'] = "Yes";
    $_SESSION['user_email'] = $_POST['email_address'];
    header('location: dashboard.php');
}
else{

    $_SESSION['login_status'] = "Your email or password are incorrect";
    header('location: fblogin.php');
    
}

//IDENTIFY EMAIIL AND PASSWORD END


?>