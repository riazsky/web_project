<?php
//DATABASE CONNECTION START

$db_connect = mysqli_connect("localhost","root","","blog_project");

//DATABASE CONNECTION END

?>