
    <script src="lib_dashboard/jquery/jquery.js"></script>
    <script src="lib_dashboard/popper.js/popper.js"></script>
    <script src="lib_dashboard/bootstrap/bootstrap.js"></script>
    <script src="lib_dashboard/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>

    <script src="js_dashboard/starlight.js"></script>

  </body>
</html>