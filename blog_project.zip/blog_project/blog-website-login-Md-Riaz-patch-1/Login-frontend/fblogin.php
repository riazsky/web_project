<?php
session_start();


?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/96c8a60c00.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Archivo+Black&display=swap" rel="stylesheet">


    <title>Login with Facebook</title>
    
  </head>
  <body>
   
<div class="login-page">

    
        <header>
 <!-------------------------Nav Start--------------------->
 
            <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navbar">
                <div class="container-fluid">
                   <a href=""><img src="images/Kate-logo.png" alt=""></a> 
                  
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                      <li class="nav-item">
                        <a class="nav-link active"  aria-current="page" href="#">Home</a>
                      </li>
                      <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                          Features
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
    <!---------------------2nd dropdown start------------>   
                          <li class="hover-me"><a class="dropdown-item" href="#">Multidropdown <i class="fa fa-angle-right"></i></a>
                            <ul class="submenu dropdown-menu">
                              <li><a class="dropdown-item" href="#">Dropdown1</a></li>
                              <li><a class="dropdown-item" href="#">Dropdown2</a></li>
                              <li><a class="dropdown-item" href="#">Dropdown3</a></li>
                            </ul>
                          </li>
    <!---------------------2nd dropdown end------------>
                          <li><a class="dropdown-item" href="#">Shortcodes</a></li>
                          <li><a class="dropdown-item" href="#">Sitemap</a></li>
                          <li><a class="dropdown-item" href="#">Error page</a></li>
                         
                        </ul>
                      </li>
                     
                      <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                         Documentation
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <li><a class="dropdown-item" href="#">Web Documentation</a></li>
                          <li><a class="dropdown-item" href="#">Video Documentation</a></li>
                        </ul>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Download This Template</a>
                          </li>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="" class='loginbtn'  onclick="document.getElementById('login-form').style.display='block'"
                          style="width:auto;">Login</a>
                        </li>                    
                  </ul>
                    <form class="d-flex">
                      <input class="form-control me-2" type="search" placeholder="Search this blog" aria-label="Search">
                      <button class="btn btn-outline-success" id="search-btn"  type="submit"><i style="color:#fff;" class="fas fa-search"></i></button>
                    </form>
                  </div>
                </div>
            </nav>

    <!-------------------------Nav End--------------------->
    </header>

    <div class="content"></div>
<div class="row">
    <!---------------------------Login Content start---------------------->

    <div id='login-form'class='login-page col-md-8'>
      <div class="form-box">
          <div class='button-box d-flex'>
              <div id='btn'></div>
              <button type='button'onclick='login()'class='toggle-btn'>Facebook</button>
              <button type='button'onclick='register()'class='toggle-btn'>Register</button>
          </div>

          <!-----------------------login Form start-------------------->
     
                <div class="login-frm">
                  <form action ='login_post.php' method = 'POST' id='login' class='input-group-login'>
                      <input type='email'class='input-field' name="email_address" placeholder='Enter your email...'>
                      <input type='password' id="password" name="password" class='input-field'placeholder='Enter facebook password...'>                
                        <!-- LOGIN STATUS START -->
                            <?php if(isset($_SESSION['login_status'])):?>
                                  <small class='text-danger'>
                                    <?=
                                      $_SESSION['login_status'];
                                      unset($_SESSION['login_status']);
                                    ?>
                                    
                                  </small>
                          <?php endif;?><br>
                          <!-- LOGIN STATUS END -->
                      <input type='checkbox'class='check-box'  onclick="showHide()"><label>Show Password</label><br>
                      <p><a  href="Forgetpassword.html">Forget password</a></p>
                      <button type='submit'class='submit-btn'>Log in</button>
                    </form>
                      <a href="gmaillogin.html"><button class="gmail-btn btn-danger"><i style="margin-right:8px;font-size:17px;" class="fab fa-google"></i> Login with Gmail</button></a>
                    
                </div>
              
          <!-----------------------login form End----------------------->




        <!----------------------------Registration form start------------------>
              <div class="registration-frm">
                <form id='register' class='input-group-register'>
                    <input type='text'class='input-field' name="" placeholder='First Name' required>
                    <input type='text'class='input-field' name="" placeholder='Last Name' required>
                    <input type='email'class='input-field' name="" placeholder='Email Id' required>
                    <input type='password' id="password2"  name="" class='input-field'placeholder='Enter Password' required>                   
                    <input type='checkbox'class='check-box' onclick="showHide2()"><label>Show Password</label>
                                                                  
                    <button type='submit'class='submit-btn'>Register</button>
                </form>
              </div>
        <!----------------------------Registration form start------------------>
      </div>
  </div>
          <!--------------------Typed Text start----------------->
          <div class="typed-text col-md-4 ">
            <h1> <span class="type-txt"></span>...</h1>
            
            </div>
            <!--------------------Typed Text start----------------->

  <!---------------------------Login Content end---------------------->
</div>
</div>
 


</div>



<!-----------------------Scroll to top Button start ------------------>
<div class="scroll-button">
  <button class="scroll-btn" onclick="topFunction()" id="myBtn"><i class="fas fa-arrow-circle-up"></i></button>
</div>
<!-----------------------Scroll  to top Button end ------------------>






    <style>
        body{
          font-family: 'Roboto', sans-serif;
            background-image:url(images/iceberg-background-wallpaper-1.jpg);
            background-size: cover; 
            background-attachment: fixed;                  
            }
           .typed-text{
            font-family: 'Archivo Black', sans-serif;
           }
           .navbar-nav{
                 margin-left:140px;
                  }
                  @media (max-width: 991px) {
  .navbar-nav{
  margin-left:0px;
}
}	
    .nav-item a{
    font-size: 14px;
    font-weight: 600;   
    color: #656565;
    word-wrap: break-word;
    margin: 0;
    padding: 0;
}
.nav-link{
  color:#fff !important;
}
.form-control{
    font-size: 14px;
    font-weight: 300;
    color: #656565;
}
.container-fluid{
    padding:15px;
    
}
.container-fluid li{
    margin-left:20px;
    color:#fff !important;
}
.container-fluid img{
    margin-left:40px;
    height:50px;
    
}
.container-fluid button{
    border:none;
}
.container-fluid button:hover{
    background-color:#fff;
}
.container-fluid button i{
    color:#1f2024;
}
.container-fluid button i:hover{
    color:#1f2024;
}
.bg-light{
  background-color:transparent !important;
}
#search-btn:hover{
  background-color:transparent;
}
.featured-slidebar{
    background:url(images/mountain2.jpg);
    position: relative;
    
    width: 100%;
    height: 400px;
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
}

@media all and (min-width: 992px) {
	.dropdown-menu li{ position: relative; 	}
	.nav-item .submenu{ 
		display: none;
		position: absolute;
		left:100%; top:-7px;
	}
	.nav-item .submenu-left{ 
		right:100%; left:auto;
	}
	.dropdown-menu > li:hover{ background-color: #f1f1f1 }
	.dropdown-menu > li:hover > .submenu{ display: block; }
}	
/* ============ desktop view .end// ============ */

/* ============ small devices ============ */
@media (max-width: 991px) {
  .dropdown-menu .dropdown-menu{
      margin-left:0.7rem; margin-right:0.7rem; margin-bottom: .5rem;
  }
}	
.typed-text h1{
  color:rgb(252, 245, 245);
  width:350px;
  margin-left:50px;
  margin-top:50px;
}


.form-box
{
  width:380px;
	height:620px;
	position:relative;
	margin:2% auto;
	background:rgba(17, 16, 16, 0.596);
	padding:10px;
  overflow: hidden;
}
.button-box
{
	width:220px;
	margin:35px auto;
	position:relative;
	box-shadow: 0 0 20px 9px #ff61241f;
	border-radius: 30px;
}
.toggle-btn
{
	padding:10px 20px;
	cursor:pointer;
	background:transparent;
	border:0;
	outline: none;
	position: relative;
    font-size:15px;
}
#btn
{
	top: 0;
	left:0;
	position: absolute;
	width: 110px;
	height: 100%;
	background: #F3C693;
	border-radius: 30px;
	transition: .5s;
}
.input-group-login
{
	top: 150px;
	position:absolute;
	width:280px;
	transition:.5s;
}
.input-group-register
{
  top: 120px;
	position:absolute;
	width:280px;
	transition:.5s;
}
.input-field
{
	width: 100%;
	padding:10px 0;
	margin:5px 0;
	border-left:0;
	border-top:0;
	border-right:0;
	border-bottom: 1px solid rgb(245, 235, 235);
	outline:none;
	background: transparent;
  color:#fff;
}

.submit-btn
{
	width: 85%;
	padding: 10px 30px;
	cursor: pointer;
	display: block;
	margin: auto;
	background: #F3C693;
	border: 0;
	outline: none;
	border-radius: 30px;
}
.facebook-btn{
  width: 80%;
	padding: 10px 30px;
	cursor: pointer;
	display: block;
	margin: auto;
	background:#3b5998;
	border: 0;
	outline: none;
	border-radius: 10px;
  font-size:15px;
  
}
.gmail-btn{
  width: 60%;
	padding: 10px 30px;
	cursor: pointer;
	display: block;
	margin: auto;
	background:#c51010;
	border: 0;
	outline: none;
	border-radius: 10px;
  font-size:15px;
  margin-top:320px;
}
.check-box
{
	margin: 30px 10px 34px 0;
}
label{
  font-size:15px;
  color:#fff;
}
.login-frm a{
  color:aqua;
  margin-left:15px;
  text-decoration:none;
}
#login
{
	left:50px;
}
#login input
{
	color:#fff;;
	font-size:15px;
}
#register
{
	left:450px;
}
#register input
{
	color:#fff;;
	font-size: 15px;
}
.scroll-btn{
  
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
  background-color: red;
  color: white;
  cursor: pointer;
  padding: 10px;
  border-radius: 4px;
}
.scroll-btn:hover{
  
  opacity: 0.7;
}
    </style>






    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
    -->

    <script type="text/javascript" src="js/typed.min.js"></script>

<script type="text/javascript">
      var typed = new Typed('.type-txt', {
      strings: ['Thoughts^1000\n `Stories` ^1000\n `And`^1000\n `Ideas`'],
      typeSpeed: 40,
      backSpeed: 40,
      loop: true,
});
</script>


    <!-------------------------------------submenu Js start------------------------->
<script>
  document.addEventListener("DOMContentLoaded", function(){
    if (window.innerWidth < 992) {
      document.querySelectorAll('.navbar .dropdown').forEach(function(everydropdown){
        everydropdown.addEventListener('hidden.bs.dropdown', function () {
            this.querySelectorAll('.submenu').forEach(function(everysubmenu){
              everysubmenu.style.display = 'none';
            });
        })
      });   
      document.querySelectorAll('.dropdown-menu a').forEach(function(element){
        element.addEventListener('click', function (e) {
            let nextEl = this.nextElementSibling;
            if(nextEl && nextEl.classList.contains('submenu')) {	
              // prevent opening link if link needs to open dropdown
              e.preventDefault();
              if(nextEl.style.display == 'block'){
                nextEl.style.display = 'none';
              } else {
                nextEl.style.display = 'block';
              }
    
            }
        });
      })
    }
    }); 
</script>
  <!-----------------------------------submenu js end-------------------->




<!-----------------------------Login button Toggle JS start---------------------->
<script>
    var x=document.getElementById('login');
    var y=document.getElementById('register');
    var z=document.getElementById('btn');
    function register()
      {
        x.style.left='-400px';
        y.style.left='50px';
        z.style.left='110px';
      }
      function login()
      {
        x.style.left='50px';
        y.style.left='450px';
        z.style.left='0px';
      }
</script>
<!-----------------------------Login button Toggle JS end---------------------->

<!-----------------------------Login page Toggle JS start---------------------->
<script>
    var modal = document.getElementById('login-form');
    window.onclick = function(event) 
    {
        if (event.target == modal) 
        {
            modal.style.display = "none";
        }
    }
</script>
<!-----------------------------Login page Toggle JS end---------------------->




<!----------------------------------Login Password hide to show JS effect start------------------->
<script>
  function showHide() {
    var x = document.getElementById("password");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  }
  </script>
  <script>
    function showHide2() {
      var x = document.getElementById("password2");
      if (x.type === "password") {
        x.type = "text";
      } else {
        x.type = "password";
      }
    }
    </script>
<!----------------------------------Login Password hide to show JS effect start------------------->


 <!---------------Scroll to top button JS--------------->
 <script>
  var mybutton = document.getElementById("myBtn");
    window.onscroll = function() {scrollFunction()};
    function scrollFunction() {
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
      } else {
        mybutton.style.display = "none";
      }
    }
    function topFunction() {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    }
    </script>




  </body>
</html>